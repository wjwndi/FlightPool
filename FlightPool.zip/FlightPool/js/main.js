

window.onload = function(){ 
function password(){

  var password = (document.getElementById('password').value);
  var password2 = (document.getElementById('password2').value);
  if(password.length < 7)
  {
    document.getElementById("okno").style.display = "block";
  }else{
     document.getElementById("okno").style.display = "none";
  }


if(password.length != 0){
  for(var i = 0;i < password.length;i++)
  {
    for(var j = 0; j <= massiv.length; j++)
    {
        if (password[i] == massiv[j])
        {
            k++
        }
    }
} 
  
  if(k < 1)
  {
    document.getElementById("okno1").style.display = "block";
  }
  else{
    document.getElementById("okno1").style.display = "none";
  }
} 


if(password.length != 0){
  for(var i = 0;i < password.length;i++)
  {
    for(var j = 0; j <= mas.length; j++)
    {
        if (password[i] == mas[j])
        {
            m++
        }
    }
} 
  
  if(m < 1)
  {
    document.getElementById("okno2").style.display = "block";
  }
  else{
    document.getElementById("okno2").style.display = "none";
  }
  } 

if (password!=password2) {
  document.getElementById("okno3").style.display = "block";
}
else{
  document.getElementById("okno3").style.display = "none";
}

}



var massiv = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
var mas = ['/', '[', ';', '.', ':', '!', '?', '@', '#', '$', '^', '&', '*', '_', '-', '=', '+', '-', '<', '>', '~', ']'];
var m =0;
var k = 0;
var check = document.getElementById('knopka'); 
check.onclick = password;
var form = document.querySelector('form');
};
